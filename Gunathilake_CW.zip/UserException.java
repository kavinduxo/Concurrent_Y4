/**
 * ********************************************************************
 * Author:  Kavindu Gunathilake
 * UoWID:   W1761405
 * Date:      23/01/11
 * ***********************************************************************
 */

public class UserException extends Exception{
    public UserException(String Err) {
        super(Err);
    }
}
